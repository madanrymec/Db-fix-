# Production setup (Windows, 40+ concurrent users, 50 lakh+ row tables)

Files: `production.py`, `db_pool.py`, `db_config.py` (template). Put them in the project root next to `app.py`.
`pip install uvicorn[standard] anyio` (waitress is WSGI-only and cannot serve FastAPI; remove it from production).

## 1. db_config.py  (routers use this one)
Use the supplied file; keep your own host/user/password/database inside `_new_connection()`.

## 2. app.py  - make its own get_db_connection use the same pool
Replace the existing function (around line 155) with:

```python
from db_config import _pool as _db_pool          # put near the other imports

def get_db_connection():
    """Connects to a MySQL database (pooled)."""
    try:
        return _db_pool.get()
    except Exception as e:
        print(f"Database connection failed: {e}")
        return None
```
`get_user_db_connection()` (login lookup) can stay as it is, it is one short query per login.

## 3. app.py  - export_ytd_excel creates a new SQLAlchemy engine on EVERY request (connection leak)
Delete these two lines inside `export_ytd_excel`:
```python
    engine_uri = f"mysql+pymysql://{DB_CONFIG['user']}:...@{DB_CONFIG['host']}/{DB_CONFIG['database']}"
    engine = create_engine(engine_uri)
```
The function then uses the module-level `engine` that is already defined near the bottom of app.py.

## 4. SQLAlchemy engines: add recycling + health check
app.py (line ~10461), product_head.py (lines ~34 and ~10365), unit_head.py (~8180), finance_head.py (~33):
```python
engine = create_engine(<your existing url>, pool_size=10, max_overflow=10,
                       pool_recycle=1800, pool_pre_ping=True)
```
(each engine keeps at most 20 connections open; two of them point to 192.7.200.4, the others to localhost.)

## 5. MySQL / MariaDB (XAMPP: C:\xampp\mysql\bin\my.ini, [mysqld] section) - restart MySQL afterwards
Adjust the memory values to your server RAM (buffer pool ~50-60% of RAM if MySQL has the machine to itself).
```ini
max_connections            = 300
thread_cache_size          = 64
table_open_cache           = 4000
innodb_buffer_pool_size    = 4G
innodb_buffer_pool_instances = 4
tmp_table_size             = 256M
max_heap_table_size        = 256M
sort_buffer_size           = 4M
join_buffer_size           = 4M
wait_timeout               = 600
interactive_timeout        = 600
max_allowed_packet         = 256M
```
Connection budget: raw pool 60 + 5 engines x up to 20 + scheduler jobs  ->  fits inside 300.

## 6. Run
`python production.py`  ->  http://192.7.200.48:8080 . Single process on purpose (scheduler jobs run once).
Logs: `logs\server.log` (rotating, 10 MB x 10); access log goes to the file only.
To start on boot use Task Scheduler or NSSM with `python production.py` and the project folder as working directory.

## 7. Check it works
```python
python -c "from db_config import _pool; c=_pool.get(); print(c.cursor().execute('select 1')); c.close(); print(_pool.stats())"
```
Expect `1` and `{'max_size': 60, 'in_use': 0, 'idle': 1}`.
While users are on the site: `SHOW PROCESSLIST;` should stay well below 100 rows, and `SHOW STATUS LIKE 'Max_used_connections';` shows the peak.
