# db_config.py  -  REPLACE the body of your existing db_config.py with this, then put your
# own host / user / password / database values into _new_connection() (same values as before).
import pymysql
from db_pool import ConnectionPool


def _new_connection():
    return pymysql.connect(
        host='localhost',
        user='root',
        password='',                 # <- keep YOUR existing password here
        database='dashboard',
        cursorclass=pymysql.cursors.DictCursor,
        charset='utf8mb4',
        connect_timeout=10,
    )


# max_size must stay below WORKER_THREADS (64) in production.py and well below MySQL max_connections
_pool = ConnectionPool(_new_connection, max_size=60, max_idle=20, acquire_timeout=30)


def get_db_connection():
    """Same name and usage as before: `with get_db_connection() as conn:` or conn.close() both work."""
    return _pool.get()
