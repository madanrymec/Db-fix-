"""
db_pool.py - small thread-safe MySQL connection pool (no extra package needed).

Why: every request used to open a brand-new MySQL connection.  With ~40 users firing 6-10 API calls
per page that means hundreds of connects/disconnects per minute and, at peak, more simultaneous
connections than MySQL allows ("Too many connections").  The pool:

  * caps the number of simultaneous DB connections (max_size) - extra requests wait instead of
    overloading MySQL,
  * re-uses warm connections (no connect cost),
  * rolls back on release, so a re-used connection never keeps an old REPEATABLE-READ snapshot
    (otherwise a dashboard could show stale data),
  * drops dead / too-old connections automatically.

Existing code does not change:  `with get_db_connection() as conn:` and
`conn = get_db_connection() ... conn.close()` both keep working - close() hands the connection back.
"""
import collections
import threading
import time


class PoolTimeout(Exception):
    """No free connection became available within acquire_timeout seconds."""


class PooledConnection:
    """Behaves like the pymysql connection; close() / leaving a `with` block returns it to the pool."""

    def __init__(self, pool, conn, created):
        self._pool = pool
        self._conn = conn
        self._created = created
        self._released = False

    def __getattr__(self, name):            # only called for attributes not found on the proxy itself
        if name in ('_pool', '_conn', '_created', '_released'):
            raise AttributeError(name)
        return getattr(self._conn, name)

    def __setattr__(self, name, value):
        if name.startswith('_'):
            object.__setattr__(self, name, value)
        else:
            setattr(self._conn, name, value)

    def close(self):
        if not self._released:
            self._released = True
            self._pool._release(self._conn, self._created)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()
        return False

    def __del__(self):                      # safety net: a forgotten close() must not leak a pool slot
        try:
            self.close()
        except Exception:
            pass


class ConnectionPool:
    def __init__(self, factory, max_size=60, max_idle=20, acquire_timeout=30,
                 ping_after=30, idle_timeout=300, recycle=1800):
        """
        factory          callable returning a NEW pymysql connection
        max_size         hard cap of simultaneous connections handed out
        max_idle         connections kept open while nobody uses them
        acquire_timeout  seconds a request waits for a free connection before PoolTimeout
        ping_after       idle connections older than this are ping-checked before re-use
        idle_timeout     idle connections older than this are closed
        recycle          connections older than this are replaced (guards against server-side timeouts)
        """
        self._factory = factory
        self._max_size = max_size
        self._max_idle = max_idle
        self._acquire_timeout = acquire_timeout
        self._ping_after = ping_after
        self._idle_timeout = idle_timeout
        self._recycle = recycle
        self._sem = threading.BoundedSemaphore(max_size)
        self._idle = collections.deque()    # (conn, created, last_used); newest on the right
        self._lock = threading.Lock()
        self._in_use = 0
        self._last_reap = time.monotonic()

    # ------------------------------------------------------------------ public
    def get(self):
        if not self._sem.acquire(timeout=self._acquire_timeout):
            raise PoolTimeout(f"No free DB connection after {self._acquire_timeout}s "
                              f"(pool max_size={self._max_size})")
        try:
            conn, created = self._checkout()
        except BaseException:
            self._sem.release()
            raise
        with self._lock:
            self._in_use += 1
        return PooledConnection(self, conn, created)

    def prewarm(self, n):
        """Open n connections up-front so the first users do not pay the connect cost."""
        held = [self.get() for _ in range(min(n, self._max_size))]
        for c in held:
            c.close()

    def stats(self):
        with self._lock:
            return {'max_size': self._max_size, 'in_use': self._in_use, 'idle': len(self._idle)}

    def close_all(self):
        with self._lock:
            idle, self._idle = list(self._idle), collections.deque()
        for conn, _, _ in idle:
            self._discard(conn)

    # ------------------------------------------------------------------ internals
    def _checkout(self):
        while True:
            with self._lock:
                item = self._idle.pop() if self._idle else None      # newest (warmest) first
            if item is None:
                break
            conn, created, last_used = item
            now = time.monotonic()
            if now - created > self._recycle or now - last_used > self._idle_timeout:
                self._discard(conn)
                continue
            if now - last_used > self._ping_after:
                try:
                    conn.ping(reconnect=False)
                except Exception:
                    self._discard(conn)
                    continue
            return conn, created
        conn = self._factory()
        if conn is None:
            raise ConnectionError("connection factory returned None")
        return conn, time.monotonic()

    def _release(self, conn, created):
        try:
            if getattr(conn, 'open', False):
                conn.rollback()                      # end the transaction / drop the old snapshot
                with self._lock:
                    if len(self._idle) < self._max_idle:
                        self._idle.append((conn, created, time.monotonic()))
                        conn = None
        except Exception:
            pass                                     # broken connection -> discarded below
        finally:
            if conn is not None:
                self._discard(conn)
            with self._lock:
                self._in_use -= 1
            self._sem.release()
            self._reap()

    def _reap(self):
        now = time.monotonic()
        if now - self._last_reap < 60:
            return
        self._last_reap = now
        stale = []
        with self._lock:
            while self._idle and now - self._idle[0][2] > self._idle_timeout:
                stale.append(self._idle.popleft()[0])
        for conn in stale:
            self._discard(conn)

    @staticmethod
    def _discard(conn):
        try:
            conn.close()
        except Exception:
            pass
