"""
production.py - production launcher for the FastAPI dashboard (Windows, single process).

Run:   python production.py

Sizing for this deployment
    * 40+ concurrent users, each page fires ~6-10 API calls at once
    * a few tables with 50 lakh+ rows, the rest ~5 lakh rows
    * all endpoints are plain `def`, so FastAPI runs them in a worker-thread pool; every running
      request holds one thread AND one MySQL connection (see db_pool.py)

    WORKER_THREADS (64)  >=  DB pool max_size (60)   -> requests queue in Python, MySQL never gets flooded
    MySQL max_connections must be above 60 (pool) + SQLAlchemy engines + scheduler jobs -> use 300.

ONE process only: app.py starts the APScheduler jobs (SAP sync, purchase sync) when it is imported.
Several workers would run every job several times, so do NOT use workers>1 or --reload here.
"""
import os
import logging
from contextlib import asynccontextmanager

import anyio
import uvicorn

from app import app, scheduler          # app.py already created the scheduler(s) and the routers

HOST = '192.7.200.48'
PORT = 8080
WORKER_THREADS = int(os.getenv('WORKER_THREADS', '64'))
DB_PREWARM = int(os.getenv('DB_PREWARM', '8'))

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_DIR = os.path.join(BASE_DIR, 'logs')
os.makedirs(LOG_DIR, exist_ok=True)

LOG_CONFIG = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'default': {'format': '%(asctime)s %(levelname)s %(name)s: %(message)s'},
    },
    'handlers': {
        'console': {'class': 'logging.StreamHandler', 'formatter': 'default'},
        'file': {'class': 'logging.handlers.RotatingFileHandler', 'formatter': 'default',
                 'filename': os.path.join(LOG_DIR, 'server.log'),
                 'maxBytes': 10 * 1024 * 1024, 'backupCount': 10, 'encoding': 'utf-8'},
    },
    'loggers': {
        'uvicorn': {'handlers': ['console', 'file'], 'level': 'INFO', 'propagate': False},
        'uvicorn.error': {'handlers': ['console', 'file'], 'level': 'INFO', 'propagate': False},
        'uvicorn.access': {'handlers': ['file'], 'level': 'INFO', 'propagate': False},   # access log -> file only
    },
}

# ----------------------------------------------------------------------------------------------
# start-up / shut-down hooks (wraps the app's own lifespan, so nothing in app.py has to change)
# ----------------------------------------------------------------------------------------------
_original_lifespan = app.router.lifespan_context


@asynccontextmanager
async def _lifespan(_app):
    # 1) enough worker threads for 40+ users (anyio's default is only 40)
    anyio.to_thread.current_default_thread_limiter().total_tokens = WORKER_THREADS
    print(f"Worker threads: {WORKER_THREADS}")

    # 2) open a few DB connections now so the first users do not wait for them
    try:
        from db_config import _pool
        _pool.prewarm(DB_PREWARM)
        print(f"DB pool ready: {_pool.stats()}")
    except Exception as exc:                       # pool not installed yet / DB down: keep starting
        print(f"DB pool prewarm skipped: {exc}")

    # 3) scheduler (app.py normally started it at import already)
    if not scheduler.running:
        scheduler.start()
        print("Production Scheduler Started...")

    try:
        async with _original_lifespan(_app) as state:
            yield state
    finally:
        if scheduler.running:
            scheduler.shutdown(wait=False)
        try:
            from db_config import _pool
            _pool.close_all()
        except Exception:
            pass


app.router.lifespan_context = _lifespan


if __name__ == "__main__":
    print(f"Server is running on http://{HOST}:{PORT}")
    uvicorn.run(
        app,
        host=HOST,
        port=PORT,
        workers=1,                 # see note at the top: scheduler must run exactly once
        backlog=2048,              # queue for bursts of new connections
        timeout_keep_alive=15,     # seconds an idle browser connection is kept open
        timeout_graceful_shutdown=15,
        log_config=LOG_CONFIG,
        access_log=True,
    )
